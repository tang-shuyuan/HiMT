#!/usr/bin/env python
# -*- coding: utf-8 -*-

from extract import main
if __name__=="__main__":
    main()