#!/usr/bin/env python
# -*- coding: utf-8 -*-

def get_versions():
    return versions[0]["number"]
versions=[{"number":"1.0.0","question":"no question"}]